function odds() {
  for (var i = 1; i < 20; i += 2) {
    console.log(i);
  }
}

function sum() {
  var sum = 0;
  for (var i = 1; i <= 5; i++) {
    sum += i;
    console.log("the num is: " + i);
    console.log("the sum is: " + sum);
  }
}

odds();
sum();
